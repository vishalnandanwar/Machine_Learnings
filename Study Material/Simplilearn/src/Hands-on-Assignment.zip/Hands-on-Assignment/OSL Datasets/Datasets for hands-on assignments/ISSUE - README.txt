# Note :
# =====

In the below mentioned file some specific lines of codes needs to be commented (done by me),
as they are looking for some files which are not available in the mentioned location of the code :

hands-on-assignment >> Datasets for hands-on assignments >> Chapter 6 - Classification >> Classification >> 'Classification.ipynb'

[15] # Image(filename='images/03_03.png', width=500)  # Commented by Simplilearn during testing
[25] # Image(filename='images/03_07.png', width=700)  # Commented by Simplilearn during testing
[27] # Image(filename='images/03_09.png', width=700)  # Commented by Simplilearn during testing
[28] # Image(filename='images/03_10.png', width=600)  # Commented by Simplilearn during testing
[32] # Image(filename='images/03_13.png', width=700)  # Commented by Simplilearn during testing
[36] # Image(filename='images/03_17.png', width=500)  # Commented by Simplilearn during testing
[37] # Image(filename='images/03_18.png', width=500)  # Commented by Simplilearn during testing
[41] # Image(filename='images/03_21.png', width=600)  # Commented by Simplilearn during testing
[43] # Image(filename='images/03_23.png', width=400)  # Commented by Simplilearn during testing