Source of this tutorial :

https://radimrehurek.com/data_science_python/
